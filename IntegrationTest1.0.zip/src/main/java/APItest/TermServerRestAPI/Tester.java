package APItest.TermServerRestAPI;

import java.util.Arrays;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class Tester 
{
	private static String[] supportedQueryTypes = {"concept-query", "concept-finder", "concept-top", "concept-lookup", "concept-subsumption", "concept-translation"};
	
	public static void main( String[] args )
	{ 
		//Invoke the tester by providing exactly 4 arguments: <server> <query> <host> and either <conceptIds> or <searchTerm>
		BasicConfigurator.configure();
		Logger.getLogger("ca.uhn.fhir.util.VersionUtil").setLevel(Level.OFF);
		Logger.getLogger("ca.uhn.fhir.context.ModelScanner").setLevel(Level.OFF);
		Logger.getRootLogger().setLevel(Level.OFF);
	    if((args[0]==null) || !(args[0].equals(RestAPITest.SNOWOWL) || args[0].equals(RestAPITest.SNOWSTORM))) {
    		System.out.println("First argument MUST NOT be null and MUST be a supported terminology server.");
	    } else if (!(Arrays.stream(supportedQueryTypes).anyMatch(args[1]::equals))){
	    	System.out.println("Wrong query type specified in second argument. Check supported types.");
	    } else if (args.length > 3 ){ //If we have more than 3 arguments then it is a fully custom Rest API test. The constructor then deduces what type of test we are doing.
	    	try {
	    		RestAPITest R0 = new RestAPITest(args[0], args[1], args[2], Integer.parseInt(args[3]));
	    		if (R0.getQueryType().equals("concept-top")){ //concept-top will find any top level concept by querying parent by parent
	    			String temp = R0.getResults();
	    			System.out.println("Got " + temp + " on first attempt.");
	    			while (!(temp.equals("138875005"))) { //SNOMED CT CONCEPT concept, the root node of all top level concepts
	    				R0.setConceptId(Integer.parseInt(temp));
	    				temp = R0.getResults();
	    				System.out.println("Got " + temp + " on subsequent attempt.");
	    			}
	    			R0.setQueryType("concept-query");
	    		}
	    		System.out.println(R0.getResults());
	        } catch (NumberFormatException e) { //if arg[3] is not an int, then we assume it is a search term.
	        	RestAPITest R0 = new RestAPITest(args[0], args[1], args[2], args[3]);
	    		System.out.println(R0.getResults());
	        }
	    } else {
    		System.out.println("Bad server argument, read the code documentation. Exiting.");
    	}
    }
}
