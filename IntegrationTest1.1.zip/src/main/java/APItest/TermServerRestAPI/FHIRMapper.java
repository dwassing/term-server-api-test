package APItest.TermServerRestAPI;

import ca.uhn.fhir.parser.IParser;

import java.util.List;

import org.hl7.fhir.r4.model.Parameters;
import org.hl7.fhir.r4.model.Parameters.ParametersParameterComponent;

import ca.uhn.fhir.context.FhirContext;

public class FHIRMapper 
{
	
	/**
	 * The FHIRMapper is a very experimental class which was developed together with Benny. It uses the HAPI FHIR IParser to extract values.
	 * However, the values we seek have proven to not always be exactly where we want them to be. At least not with the model we used
	 * to build it. Invoking it as opposed to fetching things via the JSON parser available in the RestAPITest class hampers the performance
	 * severely. While this parser can technically fetch anything one may want, it requires the user to have knowledge of the returned FHIR
	 * JSON object to supply the correct arguments. The soughtIndex property takes care of this, and is set in the respective server's 
	 * TestComponent class, based on the type of query one sends to FHIR.
	 */
	private String stringToMap = "";
	private int soughtIndex;
	private ParametersParameterComponent rr;
	
	public FHIRMapper(String json, int targetIndex)
	{
		stringToMap = json;
		soughtIndex = targetIndex;
	}
	
	public String getValueParameters()
	{
		
		// Store the result
		String result = "";
		// Create a FHIR context
		FhirContext ctx = FhirContext.forR4();
				
		// Instantiate a new parser
		IParser parser = ctx.newJsonParser();

		// Parse it
		if (this.soughtIndex == 999) { //if testing using the FHIRMapperTest class
			Parameters parsed = parser.parseResource(Parameters.class, stringToMap);
			List<ParametersParameterComponent> e = parsed.getParameter();
			rr = e.get(0);
			System.out.println(rr);
		} else { //if ran against snowowl or snowstorm.
			Parameters parsed = parser.parseResource(Parameters.class, stringToMap);
			List<ParametersParameterComponent> e = parsed.getParameter();
			rr = e.get(this.soughtIndex);
			result = rr.getValue().toString();
			
			//Below piece of code is a debugger to post all items returned by the IParser.
			/**for (int i = 0; i < e.size(); i++) {
				System.out.println(e.get(i).getValue().toString());
			}**/
		}
		
		return result;
	}	
}
